# Money Scene Prop — Android app

A single-screen **fictional money-homepage video prop** made from the editable HTML scene. It does not connect to Cash App, any banking service, or the internet. No deposits, withdrawals, or transfers are possible. The small, visible PROP marker is retained.

## What is included
- Portrait, fullscreen Android app for filming
- Home screen based on the supplied reference layout
- The custom neon green dollar/M launcher icon you selected
- Editable balances, borrowing amounts, account suffixes, Cashtag and labels
- Your changes persist privately in this app on the device
- Editor: tap the profile circle; then choose **Film screen**
- No INTERNET permission and network loads blocked

## Build with Android Studio (Windows/Mac/Linux)
1. Extract this ZIP and open the **MoneyScene_Android_Project** folder in Android Studio.
2. Allow it to install Gradle and the **Android SDK 35** if prompted. If Android Studio asks for a Gradle distribution, choose Gradle **8.9** or newer compatible with Android Gradle Plugin 8.7.3.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to your phone, open it, and approve installing from that source if Android requests permission.

## Build with GitHub Actions (no Android Studio required)
1. Create a **new private GitHub repository**.
2. Upload the extracted project files, preserving `.github/workflows/build-apk.yml`, and commit to the `main` branch.
3. Go to **Actions > Build Android APK > Run workflow** (a push to main also triggers it).
4. When it finishes, download the `MoneyScene-installable-APK` artifact, unzip, and open `app-debug.apk` on your phone.

## Building from the command line
Use a local Android SDK 35 with Java 17 and Gradle 8.9:

```sh
gradle assembleDebug
```

## Edit the design itself
The entire page is at `app/src/main/assets/index.html`. Change any text, colors, or layout there, then rebuild.

## Notes
- This archive contains **source files**, not a precompiled APK. An Android build environment is needed to produce the `.apk`.
- It is for fictional on-camera depiction only, not financial account verification.
- This project cannot access the internet, has no user credentials or payment features, and intentionally retains a visible prop label.

## Current build status
This ZIP is ready for a GitHub Actions build but **is not itself an APK**. The connected GitHub account currently has no accessible repository or GitHub App installation.
1. Create a private repository at https://github.com/new (for example `money-scene-android`).
2. Allow the connected GitHub app access to this repository under https://github.com/settings/installations .
3. Once connected, request an APK build again. The `.github/workflows/build-apk.yml` action runs when the project is committed to the default branch.
