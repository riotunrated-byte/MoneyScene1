# Money Scene 2.0 — Android film-prop simulator

A completely offline, **fictional** multi-page wallet UI for filmed scenes. No actual funds, banking credentials, payment processing, or API network calls. A permanent `PROP · FICTIONAL` identifier stays visible in filming mode.

## What's new

- Home: editable cash, savings, Bitcoin, stocks, borrow, pay-later, earnings, status and card details.
- Activity: create, edit, view, and delete fictional incoming/outgoing entries with dates, memos, statuses, and linked accounts. Transactions **do not** change balances automatically.
- Accounts: per-profile independent cash, checking, savings, market and custom accounts with custom balances and labels.
- Savings: editable savings balance and independent goals/progress.
- Card: fictional visual card, only last four decorative digits, never valid card details.
- Profiles: create, edit, duplicate, switch, and delete characters, each with their own accounts, entries, and goals.
- Scene Studio: film mode hides editing controls, not the prop label. Exit film mode by pressing and holding the top-right avatar for ~1 second.
- Persistent state: Android WebView DOM storage. Manual backup via Studio → Back up, save the JSON text, and Studio → Restore to import.
- Migration: on first launch, tries to bring across cash/savings/market figures and decorative details from the V1 storage key `money_screen_prop_scene_v3` if the existing app's data is retained.

## Android configuration

- Application ID / namespace: `com.sceneworks.moneyscene` (same as V1).
- Version: `2.0`, versionCode `2`.
- Minimum Android SDK 23, compile SDK 35, target SDK 34.
- Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9.
- Offline: the WebView loads `file:///android_asset/index.html`; Android manifest declares no INTERNET permission, and WebSettings block network loads.
- Icon: retains the bundled Money Scene green/black icon.

## Build in Android Studio

Open the project folder, sync Gradle, and choose Build → Build APK(s), or run `gradle assembleDebug` with Android SDK 35 and build-tools 35 installed. Debug result: `app/build/outputs/apk/debug/app-debug.apk`.

## Build in GitHub Actions

**If you have the project extracted in your GitHub repo:** `.github/workflows/build-apk.yml` is included, and automatically builds it.

**If you upload just the project ZIP** `MoneyScene_V2_Android.zip` to `riotunrated-byte/MoneyScene1`: also create `.github/workflows/build-v2.yml` using the separate `MoneyScene_V2_GitHub_Workflow.yml` provided alongside the project ZIP. This workflow unzips the project and compiles it, producing artifact `MoneyScene-V2-APK` with `app-debug.apk` inside.

## Updates & saved settings

**Critical:** VersionCode 2 and the same app ID do not by themselves guarantee an update in place. The initial V1 APK was a GitHub debug build, usually signed with an ephemeral debug key; a V2 debug APK from a new GitHub runner may be signed differently. Android refuses a differently-signed in-place update. If so, **export your existing scene settings before uninstalling the old app**. The V1 app does not have a JSON export, so copy important values by hand if needed. After uninstalling, reinstall V2, and re-enter values. V2 adds backup/restore for future moves.

For reliable updates in future, use the same private release signing key for each release; never commit keystores or passwords publicly. Signing setup is NOT included in this project.

## Browser preview

Open the `MoneyScene_V2_Preview.html` supplied separately, a self-contained copy of the Android WebView interface. Local browser data is separate from Android app data.

## Testing

The browser simulation was smoke-tested in Chromium for profiles, account editing, activity creation, and filming display. APK compilation needs GitHub Actions / Android SDK and has not been run for V2 at the time of packaging.
