package com.sceneworks.moneyscene;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Offline, non-transactional video prop. Loads only bundled HTML. */
public final class MainActivity extends Activity {
    private WebView screen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        enableFilmingLayout();

        screen = new WebView(this);
        screen.setBackgroundColor(Color.BLACK);
        screen.setVerticalScrollBarEnabled(false);
        screen.setHorizontalScrollBarEnabled(false);
        WebSettings settings = screen.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // retain editable amounts between launches
        settings.setAllowFileAccess(true);   // bundled index.html only
        settings.setAllowContentAccess(false);
        settings.setBlockNetworkLoads(true); // never contacts a financial service
        settings.setSupportZoom(false);
        screen.setWebChromeClient(new WebChromeClient());
        screen.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // This prop has no external pages or payment actions.
                return !"file:///android_asset/index.html".equals(request.getUrl().toString());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !"file:///android_asset/index.html".equals(url);
            }
        });
        setContentView(screen);
        screen.loadUrl("file:///android_asset/index.html");
    }

    private void enableFilmingLayout() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enableFilmingLayout();
    }

    @Override
    protected void onDestroy() {
        if (screen != null) {
            screen.destroy();
            screen = null;
        }
        super.onDestroy();
    }
}
