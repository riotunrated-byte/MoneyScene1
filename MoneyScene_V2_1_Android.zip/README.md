# Money Scene 2.1 — Android application source

An original Money Scene branded Android financial-screen interface for video production. This offline app has no network permission, no bank connection, and cannot initiate payments. The on-screen experience does not display "PROP" or "DEMO" labels. It must not be presented as evidence of actual funds, financial status, or payments.

## Features
- Distinct Money Scene styling and app icon
- Profiles with independent balances, accounts, savings goals, and activity entries
- Editable figures and activity dates, names, notes, account references and statuses
- Persistent device storage, plus backup/restore with JSON
- Camera mode hides editing controls (long-press the profile avatar to exit)
- No network permission, banking integration, financial endpoints, or payment processing

## Version information
- Application ID: `com.sceneworks.moneyscene`
- versionCode: `3`
- versionName: `2.1`
- Based on the previously compiled Version 2 project, with original-brand refinements.

## Building on GitHub
Upload **MoneyScene_V2_1_Android.zip** to the MoneyScene1 repository. Save the accompanying file as `.github/workflows/build-v2-1.yml`, using the GitHub new-file editor. That workflow unpacks the project ZIP, installs the Android SDK, compiles a debug APK and uploads it as an artifact.

Android debug builds on different GitHub runners often have different signing keys. You might need to uninstall the previous version before installing this one. If you do, back up saved profiles and figures first, because Android removes app data on uninstall.
